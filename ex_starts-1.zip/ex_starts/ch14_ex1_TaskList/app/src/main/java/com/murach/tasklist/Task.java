package com.murach.tasklist;

public class Task {

    private long taskId;
    private long listId;
    private String name;
    private String notes;
    private String completed;
    private String hidden;
    
    public static final String TRUE = "1";
    public static final String FALSE = "0";
    
    public Task() {
        name = "";
        notes = "";
        completed = FALSE;
        hidden = FALSE;
    }

    public Task(int listId, String name, String notes,
            String completed, String hidden) {
        this.listId = listId;
        this.name = name;
        this.notes = notes;
        this.completed = completed;
        this.hidden = hidden;
    }

    public Task(int taskId, int listId, String name, String notes,
            String completed, String hidden) {
        this.taskId = taskId;
        this.listId = listId;
        this.name = name;
        this.notes = notes;
        this.completed = completed;
        this.hidden = hidden;
    }

    public long getId() {
        return taskId;
    }

    public void setId(long taskId) {
        this.taskId = taskId;
    }
    
    public long getListId() {
        return listId;
    }

    public void setListId(long listId) {
        this.listId = listId;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
    
    public String getCompleted() {
        return completed;
    }

    public long getCompletedMillis() {
        return Long.valueOf(completed);
    }

    public void setCompleted(String completed) {
        this.completed = completed;    
    }
    
    public String getHidden(){
        return hidden;
    }
    
    public void setHidden(String hidden) {
        this.hidden = hidden;    
    }    
}